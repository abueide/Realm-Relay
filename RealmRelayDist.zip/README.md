How to run:

WINDOWS:
Double click Windows Start.bat

LINUX:
Open up the directory Realm-Relay is in the terminal.
Type "java -jar RealmRelayV<insert version here>.jar"

Select proxy the proxy server on the hacked client. If you don't have one,
you can get one at http://www.mpgh.net/forum/forumdisplay.php?f=599

Easy installation/updating with git:
  1. Install git (linux comes with it, google how to install it on windows)
  2. Open up terminal/git bash, and navigate to the directory you wish to save using cd c:/path/you/want/to/install/to
  3. Type in "git clone https://github.com/AMPBEdu/Realm-Relay.git"
  4. To update, type in "git pull origin"

Any donations would be extremely appreciated!

BTC: 18st8gMvHUMTpQvBbrX5koL7nF2Cc1FhtC

Paypal: gratinmpb@gmail.com OR copy paste : https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=5KRKE6B5GS29Y&lc=US&item_name=Realm%2dRelay%20Maintenance&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
